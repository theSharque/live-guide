ABOUT
-----

Commerce RMA (Return Merchandise authorization) extends Drupal Commerce in order
to give customers the opportunity to return products purchased with Commerce.

REQUIREMENTS
------------

Required : Drupal Commerce, Commerce Return, Entity API.