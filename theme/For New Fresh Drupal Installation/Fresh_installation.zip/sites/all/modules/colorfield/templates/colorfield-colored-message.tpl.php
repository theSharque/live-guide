<?php
/**
 * @file
 * Template file for the formatted "colored message" of the colorfield module.
 */
?>

<div class="colorfield-colored-message">
  <p style="color: <?php print $text_color; ?>">
    <?php print $text_message; ?>
  </p>
</div>
