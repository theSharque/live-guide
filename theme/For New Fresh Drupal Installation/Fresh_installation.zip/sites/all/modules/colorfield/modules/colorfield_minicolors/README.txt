In order to install Colorfield minicolors you first need to clone the library
jQuery miniColors hosted on Github.

Site: https://github.com/claviska/jquery-miniColors
Clone: https://github.com/claviska/jquery-miniColors/tags

Installation:
* Download & enable jQuery Update
* Switch the version of jQuery to be >= to 1.7.1
* Clone the jQuery miniColors library to sites/all/libraries/jquery-miniColors,
  the files structure should be:
  libraries/jquery-miniColors/jquery.minicolors.css
  libraries/jquery-miniColors/jquery.minicolors.js
* Enable the colorfield minicolors module.
