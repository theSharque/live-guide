This directory contains SimpleTest related include files.
